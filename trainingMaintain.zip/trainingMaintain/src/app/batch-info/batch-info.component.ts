import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { BatchService } from '../batch.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-batch-info',
  templateUrl: './batch-info.component.html',
  styleUrls: ['./batch-info.component.css']
})
export class BatchInfoComponent implements OnInit {
  sendReq(formData){
      console.log(formData)
      console.log("post successfully");
  }
  constructor(private service:BatchService) { }
  // sendReq(data){
  //   console.log(data)
  //   this.service.postReq(data).subscribe(data=>{
  //    console.log(data);
  //   },err=>{
  //     console.log(err);
  //   },()=>{
  //     console.log("sent  successfully");
  //   })
  // }
  ngOnInit() {
    var initialText = $('.editable').val();
    $('.editOption').val(initialText);
    
    $('#test').change(function(){
    var selected = $('option:selected', this).attr('class');
    var optionText = $('.editable').text();
    
    if(selected == "editable"){
      $('.editOption').show();
    
      
      $('.editOption').keyup(function(){
          var editText = $('.editOption').val();
          $('.editable').val(editText);
          $('.editable').html(editText);
      });
    
    }else{
      $('.editOption').hide();
    }
    });


    var $state = $('#state'),
    $province = $('#province');
$state.change(function() {
    if ($state.val() == 'other') {
    $province.attr('disabled', 'disabled').val('0');
       
    } else {
         $province.removeAttr('disabled');
    }
}).trigger('change'); // added trigger to calculate initial state

  }
  
}
