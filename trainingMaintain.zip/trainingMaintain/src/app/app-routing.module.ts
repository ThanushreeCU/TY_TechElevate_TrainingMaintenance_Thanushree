import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BatchInfoComponent } from './batch-info/batch-info.component';



const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"batch-info",component:BatchInfoComponent},


  
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
