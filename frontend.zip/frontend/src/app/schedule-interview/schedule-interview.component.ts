import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule-interview',
  templateUrl: './schedule-interview.component.html',
  styleUrls: ['./schedule-interview.component.css']
})
export class ScheduleInterviewComponent implements OnInit {

  constructor(private service:UserServiceService,private router:Router) { }
  sendScheduleInterview(data){
    this.service.postSchedule(data).subscribe(data=>{
     console.log(data);
     this.router.navigateByUrl('/ViewSchedule')
     this.service.getSchedule();
    },err=>{
      console.log(err);
    },()=>{
      console.log("sent  successfully");
    })
  }
  ngOnInit() {
  }

}
