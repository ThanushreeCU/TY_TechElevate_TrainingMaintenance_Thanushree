import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-view-schedule',
  templateUrl: './view-schedule.component.html',
  styleUrls: ['./view-schedule.component.css']
})
export class ViewScheduleComponent implements OnInit {

  constructor(private service:UserServiceService,private router:Router) { }
  
  sendAndRemoveSelectedCandidate(id,user){
this.service.rejectCandidate(id).subscribe(data=>{
  console.log(data)
  this.postCandidate(user)
},err=>{
  console.log(err)
},()=>{
  console.log("rejected and called to nextmethod")
})
  }
  postCandidate(user){
  this.service.postSelectedCand(user).subscribe(data=>{
    console.log(data)
    this.service.getSchedule();
    this.router.navigateByUrl('/SelectedCandidate')
  },err=>{
    console.log(err)
  },()=>{
    console.log("posted to new collection")
  })
}
deleteCand(id){
  this.service.rejectCandidate(id).subscribe(data=>{
    this.service.getSchedule();
    console.log(data)
  },err=>{
    console.log(err)
  },()=>{
    console.log("deleted")
  })
}
ngOnInit() {
}
}


  //  schedule:any[]=[];
  // select(user){
  //   // console.log(user);
  //   let userIndex=this.service.schedule.indexOf(user);
  //   console.log(userIndex);
  //   this.service.shortList.push(user);
  //   this.schedule=this.service.users.splice(userIndex,1);
  //   console.log(this.schedule);
  //   this.router.navigateByUrl('/SelectedCandidate')

  // }
  // delete(user)
  // {
  //   let userIndex=this.service.schedule.indexOf(user);
  //   console.log(userIndex);
  //   this.schedule=this.service.schedule.splice(userIndex,1);
  //   console.log(this.schedule);

  // }
  
