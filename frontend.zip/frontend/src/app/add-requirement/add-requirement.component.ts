import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-requirement',
  templateUrl: './add-requirement.component.html',
  styleUrls: ['./add-requirement.component.css']
})
export class AddRequirementComponent implements OnInit {

  constructor(private service:UserServiceService,private router:Router ) { }
  sendReq(data){
    console.log(data)
    this.service.postReq(data).subscribe(data=>{
     console.log(data);
     this.service.getAllReq();
     this.service.getDBReq();
     this.router.navigateByUrl('/ViewRequirement')
    },err=>{
      console.log(err);
    },()=>{
      console.log("sent  successfully");
    })
  }
  ngOnInit() {
  }

}
