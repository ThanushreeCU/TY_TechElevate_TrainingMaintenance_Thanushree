import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import{HttpClientModule, HttpClient} from '@angular/common/http'
import { AuthGuard } from './authguard';


import { AppComponent } from './app.component';
import {RouterModule} from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { AddRequirementComponent } from './add-requirement/add-requirement.component';
import { ViewRequirementComponent } from './view-requirement/view-requirement.component';
import { ViewScheduleComponent } from './view-schedule/view-schedule.component';
import { ScheduleInterviewComponent } from './schedule-interview/schedule-interview.component';
import { FilterPipe } from './filter.pipe';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SelectedCandidateComponent } from './selected-candidate/selected-candidate.component';
import { SignupComponent } from './signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    AddRequirementComponent,
    ViewRequirementComponent,
    ViewScheduleComponent,
    ScheduleInterviewComponent,
    FilterPipe,
    HomeComponent,
    LoginComponent,
    SelectedCandidateComponent,
    SignupComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'', component:LoginComponent},
      {path:'Home',component:HomeComponent},
      {path:'Dashboard',component:DashboardComponent,canActivate:[AuthGuard]},
      {path:'AddRequirement',component:AddRequirementComponent},
      {path:'ViewRequirement',component:ViewRequirementComponent},
      {path:'ScheduleInterview',component:ScheduleInterviewComponent},
      {path:'ViewSchedule',component:ViewScheduleComponent},
      {path:'SelectedCandidate',component:SelectedCandidateComponent},
      {path :'signup',component:SignupComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
