export class Filter{
    constructor(
    
        public Name:String,
        public Email:String,
        public Mobile:String,
        public Date:String,
        public Experience:String,
        public CCTC:String,
        public ECTC:String,
        public skills:String,
        public prevcompany:String,
        public Relocate:String,
        public NoticePeriod:String,
        public id?:String

    ){

    }
  
}