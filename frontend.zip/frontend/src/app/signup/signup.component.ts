import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private service :UserServiceService,private router:Router) { }


  postSignUp(form:NgForm){
    this.service.postSignUpForm(form.value).subscribe(data=>{
      console.log(data);
      // console.log(data.msg)
      if(data.msg==="email already exists..."){
        this.router.navigate(['/signup'])
        console.log("User Exists Already");
      form.reset();
      }else{
        this.router.navigate(['/'])
      }  
    },err=>{
      console.log(err)
    },()=>{
      console.log('signup successfully')
    })
  }

  ngOnInit() {
  }

}
