import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-selected-candidate',
  templateUrl: './selected-candidate.component.html',
  styleUrls: ['./selected-candidate.component.css']
})
export class SelectedCandidateComponent implements OnInit {

  constructor(private service:UserServiceService) { }
   
  ngOnInit() {
  }

}
