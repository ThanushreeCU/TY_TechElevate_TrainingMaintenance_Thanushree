import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-view-requirement',
  templateUrl: './view-requirement.component.html',
  styleUrls: ['./view-requirement.component.css']
})
export class ViewRequirementComponent implements OnInit {

  constructor(private service:UserServiceService) {
    
   }

  emp = {
    _id : '',
    CompanyName:'',
    skill:'',
    location:'',
    NOP:'',
    minExp:'',
    maxExp:'',
    MCTC:''
  }
  getForm(emp){
    this.emp=emp
}

updateRequirement(data){
  this.service.updateReq(data).subscribe(data=>{
    console.log(data)
    this.service.getDBReq();

  },err=>{
    console.log(err)
  },()=>{
    console.log('updated successfully')
  })
}
deleteRequirement(id){
  this.service.deleteReq(id).subscribe(data=>{
    this.service.getDBReq();
    console.log(data)
  },err=>{
    console.log(err)
  },()=>{
    console.log("deleted")
  })
}
  ngOnInit() {
  }

}
