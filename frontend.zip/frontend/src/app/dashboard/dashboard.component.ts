import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(public service :UserServiceService) {}

  AllRequirementDetails;

  checkReqSkill(skill){
    this.service.getDashBoardDataReq(skill).subscribe(data=>{ 
            this.AllRequirementDetails = data;
            console.log("All requirements", this.AllRequirementDetails)
          },err=>{
            console.log(err);
          },()=>{
            console.log("data get to dashboard1 successfully");
          });
  }



  dashboard2:any
  checkSkill2(skill){
    console.log(skill)
    this.service.getDashBoardDataSched(skill).subscribe(data=>{ 
      this.dashboard2=data;
      console.log(this.dashboard2)    
    },err=>{
      console.log(err);
    },()=>{
      console.log("data get to dashboard2 successfully");
    });
  }
dashboard3:any;
  checkSkill1(skill){
    console.log(skill)
    this.service.getDashBoardDataShortlisted(skill).subscribe(data=>{ 
        this.dashboard3=data;
        console.log(this.dashboard3)
  },err=>{
    console.log(err);
  },()=>{
    console.log("data get to dashboard3 successfully");
  })
};
    
  ngOnInit() {
  }


}
