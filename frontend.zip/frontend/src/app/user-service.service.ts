import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  
  dashboard1:any;
  dashboard2:any

  isLoggedIn=false;
  

  user:any=[];
   backendUrl="http://localhost:4000";
  shortList:any[]=[];
  
  constructor(private http:HttpClient) { 
    this.getDBReq();
    this.getSchedule();
    this.getAllReq();
    this.getShortlistedCandidate();
    this.getDashBoardDataReq("data");
    this.getDashBoardDataSched("data");
   this.getDashBoardDataShortlisted("data");
  }
  userAdd:any
  repeat:any;
  requirements:any;
  schedule:any;
  selected:any;
  allrequirements:any;

  postReq(data){
    return this.http.post(`${this.backendUrl}/postRequi`,data)
  }
  getDBReq(){
    this.http.get(`${this.backendUrl}/getDBRequirements`).subscribe(data=>{ 
      this.requirements=data; 
      console.log("all requirements", data);
    },err=>{
      console.log(err);
    },()=>{
      console.log("data get successfully");
    })
  }
  getAllReq(){
    this.http.get(`${this.backendUrl}/getallRequi`).subscribe(data=>{ 
      this.allrequirements=data; 
      console.log("all view requirements", data);
    },err=>{
      console.log(err);
    },()=>{
      console.log("data get successfully");
    })
  }
  postSchedule(data){
    return this.http.post(`${this.backendUrl}/postAddCandidate`,data)

  }
  getSchedule(){
    this.http.get(`${this.backendUrl}/getAllCandidates`).subscribe(data=>{
      this.schedule=data;
    },err=>{
      console.log(err);
    },()=>{
      console.log("data get successfully");
    })
  }

  updateReq(data){
   return this.http.post(`${this.backendUrl}/updateRequi`,data)
  }
  deleteReq(id){
    return this.http.delete(`${this.backendUrl}/deleteRequi/${id}`)
  }

  postSelectedCand(data){
return this.http.post(`${this.backendUrl}/postSelectedCandidates`,data)
  }
  rejectCandidate(id){
    return this.http.delete(`${this.backendUrl}/rejectCandidate/${id}`)

  }

  getShortlistedCandidate(){
    this.http.get(`${this.backendUrl}/getShortlistedCandidate`).subscribe(data=>{
      this.selected=data;
    },err=>{
      console.log(err);
    },()=>{
      console.log("data sent successfully");
    })
  }

getDashBoardDataReq(data){
  return this.http.get(`${this.backendUrl}/getDBRequirements/${data}`)
} 

getDashBoardDataSched(data){
  return this.http.get(`${this.backendUrl}/getDBInteSche/${data}`)
}

getDashBoardDataShortlisted(data){
  return this.http.get(`${this.backendUrl}/getDBShortlisted/${data}`)
}


postSignUpForm(data){
  return this.http.post<any>(`${this.backendUrl}/signUp`,data)
}
postLoginForm(data){
  return this.http.post<any>(`${this.backendUrl}/login`,data)

}
postLogOut(data){
  return this.http.post(`${this.backendUrl}/logout`,data)
}

  // UserLogin(){
  //   if(localStorage.getItem('token')==='true')
  //   {
  //     this.isLoggedIn=true;
  //   }
  //   else{
  //     this.isLoggedIn=false;
  //   }
  // }
}

 

  

