import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor( private service:UserServiceService, private router : Router) { }

  sendLogin(form:NgForm){
    this.service.postLoginForm(form.value).subscribe(data =>{
      console.log(data)
      if(data.msg==="please register"){
        this.router.navigate(['/signup'])
        form.reset();
      }else{
     console.log(data.isLoggedIn)
      this.service.isLoggedIn = data.isLoggedIn
      localStorage.setItem("token" , "true");
      this.router.navigateByUrl('/Dashboard');
      }
    },err=>{
      console.log(err)
    },()=>{
      console.log("login successfully")
    })
  }
  ngOnInit() {
  }

}
