import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-batch-info',
  templateUrl: './batch-info.component.html',
  styleUrls: ['./batch-info.component.css']
})
export class BatchInfoComponent implements OnInit {


  items = [];
  private pageOfItems: Array<any>;

  constructor(private http: HttpClient) {
    this.http.get<any>('../../assets/employees.json').subscribe(data => {
      this.items = data;
      console.log(this.pageOfItems);
    });
  }



  ngOnInit() {

    this.items = Array(168).fill(0).map((x, i) => ({ id: (i + 1), name: `${i + 1}` }));
  }
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
}

