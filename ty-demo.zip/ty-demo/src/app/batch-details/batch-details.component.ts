import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';
import * as $ from 'jquery';
import { NgForm } from '@angular/forms';
import { NgForOfContext } from '@angular/common';


@Component({
  selector: 'app-batch-details',
  templateUrl: './batch-details.component.html',
  styleUrls: ['./batch-details.component.css']
})
export class BatchDetailsComponent implements OnInit {

  constructor(private service: BatchService) {
  }
  batchdetails(form : NgForm) {
    console.log(form.value)
    this.service.postdetails(form.value).subscribe(data => {
      console.log(data)
     
      
    }, err => {
      console.log(err)
    }, () => {
      console.log("Post Successfully")
    })
  }
  reset(form:NgForm){
    this.service.postdetails(form.value).subscribe(data=>{
      form.reset()

    },err=>{
      console.log(err)
    },()=>{
      console.log("reset")
    })
  }

  ngOnInit() {


    const FloatLabel = (() => {    // add active class and placeholder   
      const handleFocus = (e) => {
        const target = e.target;
        target.parentNode.classList.add('active');
        target.setAttribute('placeholder', target.getAttribute('data-placeholder'));
      };    // remove active class and placeholder  
      const handleBlur = (e) => {
        const target = e.target;
        if (!target.value) { target.parentNode.classList.remove('active'); }
        target.removeAttribute('placeholder');
      };      // register events  
      const bindEvents = (element) => {
        const floatField = element.querySelector('input');
        floatField.addEventListener('focus', handleFocus);
        floatField.addEventListener('blur', handleBlur);
      };    // get DOM elements  
      const init = () => {
        const floatContainers = document.querySelectorAll('.float-container');
        floatContainers.forEach((element) => {
          if (element.querySelector('input').value) {
            element.classList.add('active');
          }
          bindEvents(element);
        });
      };
      return { init: init };
    })();
    FloatLabel.init();


    var initialText = $('.editable').val();
    $('.ty-editOption').val(initialText);
    $('#test').change(function () {
      var selected = $('option:selected', this).attr('class');
      var optionText = $('.editable').text();
      if (selected == "editable") {
        $('.ty-editOption').show();
        $('.ty-editOption').keyup(function () {
          var editText = $('.ty-editOption').val();
          $('.editable').val(editText);
          $('.editable').html(editText);
        });
      } else {
        $('.ty-editOption').hide();
      }
    });


    var $batchtype = $('#batchtype'),
      $feeInfo = $('#province');
    $batchtype.change(function () {
      if ($batchtype.val() == 'other') {
        $feeInfo.attr('disabled', 'disabled').val('0');
      } else {
        $feeInfo.removeAttr('disabled');
      }
    }).trigger('change');
  }
}


