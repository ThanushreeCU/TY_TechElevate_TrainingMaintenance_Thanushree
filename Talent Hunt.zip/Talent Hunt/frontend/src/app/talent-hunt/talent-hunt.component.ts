import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-builder',
  template: `
       <app-side-nav></app-side-nav>
  `,
  styles: []
})
export class TalentHuntComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
