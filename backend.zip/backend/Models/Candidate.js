const mongoose=require('mongoose');
const Schema=mongoose.Schema;


const candidateSchema=new Schema({
    name:{
        type:String
    },
    email:{
        type:String
    },
    mobile:{
        type:Number
    },
    date:{
        type:Date
    },
    exp:{
        type:String
    },
    cctc:{
        type:Number
    },
    ectc:{
        type:Number
    }
    ,
    skills:{
        type:String
    },
    prevcompany:{
        type:String
    },
    relocate:{
        type:String
    },
    nop:{
        type:Number
    }
})

module.exports=mongoose.model('Candidate',candidateSchema);