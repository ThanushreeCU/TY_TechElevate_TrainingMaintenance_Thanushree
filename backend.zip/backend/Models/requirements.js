const mongoose=require('mongoose');
const Schema=mongoose.Schema;


const reqSchema=new Schema({
    CompanyName:{
        type:String,
        required:true
    },
    skill:{
        type:String,
        required:true
    },
    location:{
        type:String,
        required:true
    },
    NOP:{
        type:Number,
        required:true
    },
    minExp:{
        type:String,
        required:true
    },
    maxExp:{
        type:String,
        required:true
    },
    MCTC:{
        type:Number,
        required:true
    }
    })

module.exports=mongoose.model('Requirement',reqSchema);