const Candidate = require('../Models/Candidate');
const ShortlistedCandidate = require('../Models/Shortlisted')


exports.postAddCandidate = (req, res, next) => {
    let user = new Candidate({
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        date: req.body.date,
        exp: req.body.exp,
        cctc: req.body.cctc,
        ectc: req.body.ectc,
        skills: req.body.skills,
        prevcompany: req.body.prevcompany,
        relocate: req.body.relocate,
        nop: req.body.nop


    })
    user.save().then(data => {
        res.json(data)
    }).catch(err => {
        console.log(err)
    })
}

exports.getAllCandidate = (req, res, next) => {
    Candidate.find().then(data => {
        res.json(data)
    }).catch(err => {
        console.log(err);
    })
}

exports.postSelectedCandidate = (req, res, next) => {
    let id = req.body.id
    Candidate.findById(id).then(task => {
        console.log(task);
        let sched = new ShortlistedCandidate({
            name: task.name,
            email: task.email,
            mobile: task.mobile,
            date: task.date,
            exp: task.exp,
            cctc: task.cctc,
            ectc: task.ectc,
            skills: task.skills,
            prevcompany: task.prevcompany,
            relocate: task.relocate,
            nop: task.nop
        })
        sched.save().then(result => {
            Candidate.findByIdAndRemove(id).then(result => {
                return res.json({msg : "canididate got shortlisted"})
            })
        })
    }).catch(err => {
        console.log(err)

    })
}


exports.rejectCandidate = (req, res, next) => {
    let id = req.params.id
    Candidate.findByIdAndRemove(id).then(result => {
        res.json(result)
    }).catch(err => {
        console.log(err);
    })
}

exports.getShortlistedCandidate = (req, res, next) => {
    ShortlistedCandidate.find().then(data => {
        res.json(data)
    }).catch(err => {
        console.log(err);
    })
}