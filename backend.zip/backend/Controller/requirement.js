const Requirement = require('../Models/requirements');
const Candidate = require('../Models/Candidate');
const ShortlistedCandidate = require('../Models/Shortlisted')


// adding requirements
exports.postAddRequirement = (req, res, next) => {
    let CompanyName = req.body.CompanyName;
    let skill = req.body.skill;
    let NOP = req.body.NOP;
    Requirement.find({ $and: [{ CompanyName: { $eq: CompanyName } }, { skill: { $eq: skill } }] }).then(requirement => {
        if (requirement.length > 0) {
            for (let requi of requirement) {
                requi.NOP = requi.NOP + NOP;
                requi.save().then(savedReq => {
                    return res.json(savedReq);
                })
            }
        } else {
            new Requirement({
                CompanyName: req.body.CompanyName,
                skill: req.body.skill,
                location: req.body.location,
                NOP: req.body.NOP,
                minExp: req.body.minExp,
                maxExp: req.body.maxExp,
                MCTC: req.body.MCTC
            }).save().then(data => {
                return res.json(data)
            })
        }
    }).catch(err => {
        console.log(err);
    })
}

// getting all requirements
exports.getAllRequirements = (req, res, next) => {
    Requirement.find().then(requirements => {
        res.json(requirements);
    }).catch(err => {
        console.log(err);
    })
}



// updating requirements
exports.updateRequirement = (req, res, next) => {
    let id = req.body.id
    Requirement.findById(id).then(emp => {
        emp.CompanyName = req.body.CompanyName;
        emp.skill = req.body.skill;
        emp.location = req.body.location;
        emp.NOP = req.body.NOP;
        emp.minExp = req.body.minExp;
        emp.maxExp = req.body.maxExp;
        emp.MCTC = req.body.MCTC;
        emp.save().then(result => {
           return res.json(emp)
        })
    }).catch(err => {
        console.log(err);
    })
}



// removing requirement
exports.deleteRequirement = (req, res, next) => {
    let id = req.params.id
    Requirement.findByIdAndRemove(id).then(result => {
        res.json(result)
    }).catch(err => {
        console.log(err);
    })

}


// getting dashboard all requirements based on skill and count
exports.getDBRequirements = (req, res, next) => {
    Requirement.aggregate([
        { $group: { _id: "$skill", count: { $sum: 1 } } }
    ]).then(data => {
        res.json(data);
    }).catch(err => {
        console.log(err);
    })
}

// getting details of the requiremnts in the dashboard
exports.getDBRequiDetails = (req, res, next) => {
    let skillName = req.params.skillName;
    console.log(skillName)
    Requirement.find({ "skill": skillName }).then(requirement => {
        res.json(requirement)
    }).catch(err => {
        console.log(err);
    })
}


exports.getDBInterviewSheduled = (req, res, next) => {
    let skillNameSched = req.params.skillName;
    Candidate.find({ "skills": skillNameSched }).then(requirementschedule => {
        res.json(requirementschedule)
    }).catch(err => {
        console.log(err);
    })
}


exports.getDBShortListed = (req, res, next) => {
    let skillNameSelected = req.params.skillName;
    console.log(skillNameSelected);
    ShortlistedCandidate.find({ "skills": skillNameSelected }).then(requirementselected => {
        res.json(requirementselected)
    }).catch(err => {
        console.log(err);
    })
}


