const loginUser=require('../Models/login')
const bcrypt=require('bcryptjs');



exports.postSignUpForm=(req,res,next)=>{
    let email=req.body.email;
    let password=req.body.password;
    loginUser.findOne({email:email}).then(user=>{
        console.log(user);
        if(user){
        res.json({msg:"email already exists..."});
        }
        //this is else part
        return bcrypt.hash(password,12).then(hashedPassword=>{
            let user=new loginUser({
                email:email,
                password:hashedPassword
            })
           user.save().then(userDetails =>{
            res.json({
                user:userDetails,
                msg:"Registered Successfully Please Login..."})
        })
    })
    }).catch(err =>{
        console.log(err);
    })
}


exports.postLoginForm=(req,res,next)=>{
    let email=req.body.email;
    let password=req.body.password;
    loginUser.findOne({email:email}).then(user=>{
        if(!user){
         res.json({msg : 'please register'})
        }
      return bcrypt.compare(password,user.password).then(doMatch=>{
            if(doMatch){
                // req.session.user=user;
                req.session.isLoggedIn=true;
                 req.session.save();
                   res.json({
                       user:user,
                        isLoggedIn : req.session.isLoggedIn
                   
                })
            }
        })
    }).catch(err=>{
        console.log(err);
    })
}

exports.postLogoutForm=(req,res,next)=>{
    req.session.destroy();
    res.json({msg:"Logged Out Successfully"})
}

