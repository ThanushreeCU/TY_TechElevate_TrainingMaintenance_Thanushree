const express=require('express');
const router=express.Router();
const requirementController=require('../Controller/requirement');


router.post('/postRequi',requirementController.postAddRequirement);

router.get('/getallRequi' , requirementController.getAllRequirements);

router.post('/updateRequi',requirementController.updateRequirement);

router.delete('/deleteRequi/:id',requirementController.deleteRequirement);

router.get('/getDBRequirements',requirementController.getDBRequirements);

router.get('/getDBRequirements/:skillName',requirementController.getDBRequiDetails);

router.get('/getDBInteSche/:skillName',requirementController.getDBInterviewSheduled);

router.get('/getDBShortlisted/:skillName',requirementController.getDBShortListed);



module.exports=router;