const express=require('express');
const router=express.Router();
const sheduleController=require('../Controller/schedInterview')



router.post('/postAddCandidate',sheduleController.postAddCandidate);

router.get('/getAllCandidates',sheduleController.getAllCandidate);

router.post('/postSelectedCandidates',sheduleController.postSelectedCandidate);

router.delete('/rejectCandidate/:id',sheduleController.rejectCandidate);

router.get('/getShortlistedCandidate',sheduleController.getShortlistedCandidate);




module.exports=router;